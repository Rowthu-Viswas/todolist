from django.shortcuts import render, redirect, get_object_or_404
from .models import TodoItem
from .forms import TodoItemForm

def index(request):
    todo_items = TodoItem.objects.all()
    return render(request, 'todoapp/index.html', {'todo_items': todo_items})

def add_todo(request):
    if request.method == 'POST':
        form = TodoItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = TodoItemForm()
    return render(request, 'todoapp/add_todo.html', {'form': form})

def update_todo(request, pk):
    todo_item = get_object_or_404(TodoItem, pk=pk)
    if request.method == 'POST':
        form = TodoItemForm(request.POST, instance=todo_item)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = TodoItemForm(instance=todo_item)
    return render(request, 'todoapp/update_todo.html', {'form': form})

def delete_todo(request, pk):
    todo_item = get_object_or_404(TodoItem, pk=pk)
    if request.method == 'POST':
        todo_item.delete()
        return redirect('index')
    return render(request, 'todoapp/delete_todo.html', {'todo_item': todo_item})